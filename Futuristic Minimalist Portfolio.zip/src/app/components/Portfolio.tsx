import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Github, Linkedin, Mail, Award, Code2 } from 'lucide-react';
import profilePhoto from 'figma:asset/48447617c6fcc643e1b9a267dabd06791e742abb.png';

const projects = [
  {
    id: 1,
    title: 'Neural Network Platform',
    description: 'AI-powered analytics dashboard with real-time data processing',
    image: 'https://i.imgur.com/xtSQFRT.png',
    technologies: ['React', 'TensorFlow.js', 'Node.js', 'WebGL'],
  },
  {
    id: 2,
    title: 'Smart Architecture Hub',
    description: 'Modern building management system with IoT integration',
    image: 'https://i.imgur.com/JndE9Kv.png',
    technologies: ['Vue.js', 'Python', 'MQTT', 'PostgreSQL'],
  },
  {
    id: 3,
    title: 'Digital Nexus',
    description: 'Blockchain-based decentralized application for secure transactions',
    image: 'https://images.unsplash.com/photo-1633743252577-ccb68cbdb6ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGRpZ2l0YWwlMjBhcnR8ZW58MXx8fHwxNzY1ODUxMTE0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    technologies: ['Solidity', 'Web3.js', 'React', 'Ethereum'],
  },
];

const achievements = [
  {
    id: 1,
    title: 'Best Innovation Award 2024',
    organization: 'Tech Excellence Summit',
    description: 'Recognized for groundbreaking work in AI-driven solutions',
  },
  {
    id: 2,
    title: 'Open Source Contributor',
    organization: 'GitHub',
    description: '500+ contributions to major open source projects',
  },
  {
    id: 3,
    title: 'Speaker at DevCon 2023',
    organization: 'International Developer Conference',
    description: 'Presented "Future of Web Architecture"',
  },
];

export default function Portfolio() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="border-b border-white/10"
      >
        <div className="max-w-7xl mx-auto px-6 py-8 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <img src={profilePhoto} alt="Profile" className="w-10 h-10 rounded-sm object-cover" />
            <span className="tracking-wider">Abdullah Alqinayh</span>
          </div>
          <nav className="flex gap-8">
            <a href="#about" className="hover:text-gray-400 transition-colors">About</a>
            <a href="#projects" className="hover:text-gray-400 transition-colors">Projects</a>
            <a href="#achievements" className="hover:text-gray-400 transition-colors">Achievements</a>
          </nav>
        </div>
      </motion.header>

      {/* Hero Section / About */}
      <section id="about" className="max-w-7xl mx-auto px-6 py-32">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="max-w-4xl"
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="h-px w-12 bg-white" />
            <span className="text-sm tracking-widest text-gray-400">Product Enthusiast</span>
          </div>
          <h1 className="mb-8 leading-tight">
            Building the future,
            <br />
            one pixel at a time.
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mb-12 leading-relaxed">
            Product Manager with a strong bias toward action. I enjoy early-stage ambiguity, validating ideas with users, and turning insights into scalable products that create real business value.
          </p>
          <div className="flex gap-4">
            <motion.a
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href="mailto:hello@example.com"
              className="flex items-center gap-2 px-6 py-3 bg-white text-black hover:bg-gray-200 transition-colors"
            >
              <Mail className="w-4 h-4" />
              Get in touch
            </motion.a>
            
            <motion.a
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-6 py-3 border border-white/20 hover:bg-white/5 transition-colors"
            >
              <Linkedin className="w-4 h-4" />
              LinkedIn
            </motion.a>
          </div>
        </motion.div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="max-w-7xl mx-auto px-6 py-32 border-t border-white/10">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex items-center gap-4 mb-16">
            <Code2 className="w-6 h-6" />
            <h2>Selected Projects</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group cursor-pointer"
                onClick={() => navigate(`/project/${project.id}`)}
              >
                <div className="relative overflow-hidden bg-gray-900 mb-4 aspect-[4/3]">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end justify-end p-6">
                    <ArrowRight className="w-6 h-6 transform translate-x-0 group-hover:translate-x-2 transition-transform" />
                  </div>
                </div>
                <h3 className="mb-2">{project.title}</h3>
                <p className="text-gray-400 mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="text-xs px-3 py-1 border border-white/10 text-gray-400"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Achievements Section */}
      <section id="achievements" className="max-w-7xl mx-auto px-6 py-32 border-t border-white/10">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex items-center gap-4 mb-16">
            <Award className="w-6 h-6" />
            <h2>Main Achievements</h2>
          </div>
          <div className="space-y-6">
            {achievements.map((achievement, index) => (
              <motion.div
                key={achievement.id}
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="border border-white/10 p-8 hover:bg-white/5 transition-colors group"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="mb-2">{achievement.title}</h3>
                    <p className="text-sm text-gray-500 mb-3">{achievement.organization}</p>
                    <p className="text-gray-400">{achievement.description}</p>
                  </div>
                  <div className="w-12 h-12 border border-white/20 flex items-center justify-center group-hover:bg-white group-hover:text-black transition-colors">
                    <span className="text-xs">{String(index + 1).padStart(2, '0')}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="flex justify-between items-center">
            <p className="text-sm text-gray-500">© 2024 All rights reserved</p>
            <div className="flex gap-6">
              <a href="https://github.com" className="text-gray-500 hover:text-white transition-colors">
                <Github className="w-5 h-5" />
              </a>
              <a href="https://linkedin.com" className="text-gray-500 hover:text-white transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="mailto:hello@example.com" className="text-gray-500 hover:text-white transition-colors">
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}