import { motion } from 'motion/react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ExternalLink, Github } from 'lucide-react';


const projectDetails = {
  '1': {
    title: 'Neural Network Platform',
    description: 'AI-powered analytics dashboard with real-time data processing',
    image: 'https://images.unsplash.com/photo-1720962158813-29b66b8e23e1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmdXR1cmlzdGljJTIwdGVjaG5vbG9neSUyMGRhcmt8ZW58MXx8fHwxNzY1OTEyNTAzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    technologies: ['React', 'TensorFlow.js', 'Node.js', 'WebGL'],
    challenge: 'Creating a platform that could process and visualize complex neural network data in real-time while maintaining optimal performance across different devices.',
    solution: 'Implemented a hybrid rendering approach using WebGL for visualization and web workers for data processing. This allowed us to handle large datasets without blocking the main thread.',
    impact: 'Reduced data processing time by 60% and enabled real-time insights for over 10,000 daily active users.',
    features: [
      'Real-time neural network visualization',
      'Custom training pipeline',
      'Performance monitoring dashboard',
      'Export and sharing capabilities',
    ],
  },
  '2': {
    title: 'Smart Architecture Hub',
    description: 'Modern building management system with IoT integration',
    image: 'https://images.unsplash.com/photo-1580922942632-fb585198592e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhcmNoaXRlY3R1cmUlMjBtaW5pbWFsfGVufDF8fHx8MTc2NTkwODU1Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    technologies: ['Vue.js', 'Python', 'MQTT', 'PostgreSQL'],
    challenge: 'Integrating thousands of IoT sensors across multiple buildings while ensuring data accuracy and system reliability.',
    solution: 'Developed a microservices architecture with MQTT for real-time communication and implemented redundancy measures to prevent data loss.',
    impact: 'Managed 5,000+ IoT devices with 99.9% uptime and reduced energy consumption by 30% through intelligent automation.',
    features: [
      'Centralized building control',
      'Energy consumption analytics',
      'Predictive maintenance alerts',
      'Mobile app integration',
    ],
  },
  '3': {
    title: 'Digital Nexus',
    description: 'Blockchain-based decentralized application for secure transactions',
    image: 'https://images.unsplash.com/photo-1633743252577-ccb68cbdb6ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGRpZ2l0YWwlMjBhcnR8ZW58MXx8fHwxNzY1ODUxMTE0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    technologies: ['Solidity', 'Web3.js', 'React', 'Ethereum'],
    challenge: 'Building a user-friendly interface for blockchain interactions while ensuring maximum security and transparency.',
    solution: 'Created a progressive web app with built-in wallet integration and implemented comprehensive smart contract testing and auditing.',
    impact: 'Processed over $2M in secure transactions with zero security incidents and achieved 4.8/5 user satisfaction rating.',
    features: [
      'Decentralized transaction processing',
      'Multi-wallet support',
      'Smart contract automation',
      'Transaction history and analytics',
    ],
  },
};

export default function ProjectDetail() {
  const navigate = useNavigate();
  const { id } = useParams();
  const project = id ? projectDetails[id as keyof typeof projectDetails] : null;

  if (!project) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="mb-4">Project not found</h1>
          <button onClick={() => navigate('/')} className="text-gray-400 hover:text-white">
            Return home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="border-b border-white/10"
      >
        <div className="max-w-7xl mx-auto px-6 py-8">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors group"
          >
            <ArrowLeft className="w-5 h-5 transform group-hover:-translate-x-1 transition-transform" />
            Back to portfolio
          </button>
        </div>
      </motion.header>

      {/* Hero Image */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="max-w-7xl mx-auto px-6 py-12"
      >
        <div className="aspect-[21/9] overflow-hidden bg-gray-900">
          <img
            src={project.image}
            alt={project.title}
            className="w-full h-full object-cover"
          />
        </div>
      </motion.div>

      {/* Project Info */}
      <div className="max-w-7xl mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="grid grid-cols-1 lg:grid-cols-3 gap-16"
        >
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            <div>
              <h1 className="mb-4">{project.title}</h1>
              <p className="text-xl text-gray-400">{project.description}</p>
            </div>

            <div>
              <h3 className="mb-4">The Challenge</h3>
              <p className="text-gray-400 leading-relaxed">{project.challenge}</p>
            </div>

            <div>
              <h3 className="mb-4">The Solution</h3>
              <p className="text-gray-400 leading-relaxed">{project.solution}</p>
            </div>

            <div>
              <h3 className="mb-4">Impact</h3>
              <p className="text-gray-400 leading-relaxed">{project.impact}</p>
            </div>

            <div>
              <h3 className="mb-6">Key Features</h3>
              <ul className="space-y-3">
                {project.features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-3 text-gray-400">
                    <div className="w-1.5 h-1.5 bg-white mt-2.5 flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            <div className="border border-white/10 p-6">
              <h4 className="mb-4 text-sm tracking-wider text-gray-400">TECHNOLOGIES</h4>
              <div className="flex flex-wrap gap-2">
                {project.technologies.map((tech) => (
                  <span
                    key={tech}
                    className="px-3 py-1 border border-white/10 text-sm"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <motion.a
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                href="https://example.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full px-6 py-3 bg-white text-black hover:bg-gray-200 transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
                Visit Project
              </motion.a>
              <motion.a
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full px-6 py-3 border border-white/20 hover:bg-white/5 transition-colors"
              >
                <Github className="w-4 h-4" />
                View Code
              </motion.a>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Footer */}
      <footer className="border-t border-white/10 mt-32">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="flex justify-between items-center">
            <p className="text-sm text-gray-500">© 2024 All rights reserved</p>
            <button
              onClick={() => navigate('/')}
              className="text-gray-400 hover:text-white transition-colors"
            >
              Back to top
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
