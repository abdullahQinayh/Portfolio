
  # Futuristic Minimalist Portfolio

  This is a code bundle for Futuristic Minimalist Portfolio. The original project is available at https://www.figma.com/design/RkvvKdWd5pys55mB10c15k/Futuristic-Minimalist-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  